export function SidebarFooter() {
    return <div className="sidebar-footer">Footer</div>;
  }